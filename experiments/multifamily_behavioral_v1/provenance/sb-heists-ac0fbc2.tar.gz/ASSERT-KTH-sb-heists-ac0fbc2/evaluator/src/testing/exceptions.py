class HardhatRunnerError(Exception):
    pass