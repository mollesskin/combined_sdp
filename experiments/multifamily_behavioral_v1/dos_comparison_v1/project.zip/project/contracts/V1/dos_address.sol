/*
 * @source: https://github.com/SmartContractSecurity/SWC-registry/blob/master/test_cases/dos_gas_limit/dos_address.sol
 * @author: -
 * @vulnerable_at_lines: 16,17,18
 */

pragma solidity ^0.4.25;

contract DosGas {

    address[] creditorAddresses;
    bool win = false;
    bool public clearing = false;

    function emptyCreditors() public {
        // <yes> <report> DENIAL_OF_SERVICE
        if (!clearing) {
            if (creditorAddresses.length <= 1500) return;
            clearing = true;
        }
        uint work = creditorAddresses.length > 350 ? 350 : creditorAddresses.length;
        creditorAddresses.length -= work;
        if (creditorAddresses.length == 0) {
            win = true;
            clearing = false;
        }
    }

    function addCreditors() public returns (bool) {
        require(!clearing);
        for(uint i=0;i<350;i++) {
          creditorAddresses.push(msg.sender);
        }
        return true;
    }

    function iWin() public view returns (bool) {
        return win;
    }

    function numberCreditors() public view returns (uint) {
        return creditorAddresses.length;
    }
}
