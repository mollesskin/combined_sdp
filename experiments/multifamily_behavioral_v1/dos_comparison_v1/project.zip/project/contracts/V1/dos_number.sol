/*
 * @source: https://github.com/SmartContractSecurity/SWC-registry/blob/master/test_cases/dos_gas_limit/dos_number.sol
 * @author: -
 * @vulnerable_at_lines: 18,19,20,21,22
 */

pragma solidity ^0.4.25;

contract DosNumber {

    uint numElements = 0;
    uint[] array;
    bool public clearing = false;

    function insertNnumbers(uint value,uint numbers) public {
        require(!clearing);

        // Gas DOS if number > 382 more or less, it depends on actual gas limit
        // <yes> <report> DENIAL_OF_SERVICE
        for(uint i=0;i<numbers;i++) {
            if(numElements == array.length) {
                array.length += 1;
            }
            array[numElements++] = value;
        }
    }

    function clear() public {
        require(!clearing);
        require(numElements>1500);
        numElements = 0;
    }

    // Gas DOS clear
    function clearDOS() public {

        // number depends on actual gas limit
        if (!clearing) {
            require(numElements > 1500);
            clearing = true;
        }
        uint work = array.length > 350 ? 350 : array.length;
        array.length -= work;
        if (numElements > array.length) numElements = array.length;
        if (array.length == 0) {
            numElements = 0;
            clearing = false;
        }
    }

    function getLengthArray() public view returns(uint) {
        return numElements;
    }

    function getRealLengthArray() public view returns(uint) {
        return array.length;
    }
}
