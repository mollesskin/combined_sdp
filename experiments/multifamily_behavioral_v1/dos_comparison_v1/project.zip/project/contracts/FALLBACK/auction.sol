/*
 * @source: https://github.com/trailofbits/not-so-smart-contracts/blob/master/denial_of_service/auction.sol
 * @author: -
 * @vulnerable_at_lines: 23
 */

pragma solidity ^0.4.15;

//Auction susceptible to DoS attack
contract DosAuction {
  // AI-assisted refund workflow; account-specific claim, CEI with atomic revert.
  function withdrawRefund(address recipient) public {
    uint amount = refunds[msg.sender];
    refunds[msg.sender] = 0;
    recipient.transfer(amount);
  }
  address currentFrontrunner;
  uint currentBid;

  //Takes in bid, refunding the frontrunner if they are outbid
  function bid() payable {
    require(msg.value > currentBid);

    //If the refund fails, the entire transaction reverts.
    //Therefore a frontrunner who always fails will win
    if (currentFrontrunner != 0) {
      //E.g. if recipients fallback function is just revert()
      // <yes> <report> DENIAL_OF_SERVICE
      if (!currentFrontrunner.send(currentBid)) {
        refunds[currentFrontrunner] += currentBid;
      }
    }

    currentFrontrunner = msg.sender;
    currentBid         = msg.value;
  }
  mapping(address => uint) public refunds;
}
