pragma solidity ^0.4.25;
// AI-assisted local test fixture; controls a genuinely refusing auction recipient.
contract RefundAPI { function bid() public payable; function withdrawRefund(address recipient) public; }
contract BidderFixture {
 address public controller;
 constructor() public { controller = msg.sender; }
 function placeBid(address auction) public payable { require(msg.sender == controller); RefundAPI(auction).bid.value(msg.value)(); }
 function claim(address auction,address recipient) public { require(msg.sender == controller); RefundAPI(auction).withdrawRefund(recipient); }
 function() public payable { revert(); }
}
